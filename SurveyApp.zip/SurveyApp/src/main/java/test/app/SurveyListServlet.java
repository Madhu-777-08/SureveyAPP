package test.app;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class SurveyListServlet
 */
@WebServlet("/api/surveys/all")
public class SurveyListServlet extends HttpServlet {
    private static final String FILE_PATH = "D:\\SAVEAIDATAAPP\\LOGINDETAILS\\surveys.jsonl";

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	   response.setContentType("application/json");
           PrintWriter out = response.getWriter();

           File file = new File(FILE_PATH);
           if (!file.exists()) {
               out.write("[]");
               return;
           }

           StringBuilder jsonArray = new StringBuilder();
           jsonArray.append("[");
           try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
               String line;
               boolean first = true;
               while ((line = reader.readLine()) != null) {
                   System.out.println("Reading line: " + line); // DEBUG
                   if (!first) jsonArray.append(",");
                   jsonArray.append(line);
                   first = false;
               }
           }
           jsonArray.append("]");
           out.write(jsonArray.toString());
    }
}