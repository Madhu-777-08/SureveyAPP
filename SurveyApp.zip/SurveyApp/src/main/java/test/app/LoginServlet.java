package test.app;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {
    private static final String FILE_PATH = "D:\\SAVEAIDATAAPP\\LOGINDETAILS\\USERS.txt"; // Match with SignupServlet

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	String email = request.getParameter("email");
        String password = request.getParameter("password");

        boolean isValidUser = false;

        // Check user in file
        try (BufferedReader reader = new BufferedReader(new FileReader(FILE_PATH))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length == 2 && parts[0].equals(email) && parts[1].equals(password)) {
                    isValidUser = true;
                    break;
                }
            }
        }

        if (isValidUser) {
            response.sendRedirect("ViewSurvey.html"); // Success
        } else {
        	response.sendRedirect("Login.html?error=true"); 
        }
    }
}